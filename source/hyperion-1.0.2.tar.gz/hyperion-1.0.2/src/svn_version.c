/* SVN repository version.
 * This auto-generated file must not be included in svn, but must be included
 * in tarballs.
 */
#include "ircd.h"
const char* serial = "230" SERIAL_ADDENDUM;
